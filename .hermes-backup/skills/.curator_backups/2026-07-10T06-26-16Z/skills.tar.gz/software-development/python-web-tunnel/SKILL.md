---
name: python-web-tunnel
description: Build Python Flask web apps with AI API backends, tunnel them for mobile/remote access, and handle API quirks.
category: software-development
triggers:
  - "build a web app / dashboard with a local Python backend"
  - "expose a local server to the internet via tunnel"
  - "mobile-accessible web UI from desktop machine"
  - "Gemini / DeepSeek / OpenAI API integration in Flask"
  - "file upload to AI API with video analysis"
---

# Python Web App + Tunnel — Patterns & Pitfalls

Class-level guide for building a local Flask proxy with AI API backends
and exposing it via tunnels for mobile access.

---

## 1. Architecture: Single-Origin Flask

Serve frontend static files FROM the Flask backend — not from a separate HTTP server.
This eliminates all CORS issues and long-request tunnel timeouts.

```python
from pathlib import Path
from flask import Flask, send_from_directory

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"

@app.route("/")
def index():
    return send_from_directory(str(FRONTEND_DIR), "index.html")

@app.route("/<path:path>")
def static_files(path):
    return send_from_directory(str(FRONTEND_DIR), path)
```

**Why:** The JS frontend makes fetch() calls to `/analyze` (same origin).
No CORS headers needed. No cross-tunnel fetch issues.

## 2. Tunnel Selection

| Tunnel    | Long requests (>30s) | Setup                  | Reliability |
|-----------|---------------------|------------------------|-------------|
| serveo.net| ❌ Drops            | `ssh -R 80:localhost:PORT serveo.net` | Poor — drops long POSTs |
| localtunnel | ❌ Drops          | `npx localtunnel --port PORT` | Poor — 503s under load |
| **cloudflared** | ✅ Handles    | `cloudflared tunnel --url http://localhost:PORT` | **Best** — no account needed |

**Always use cloudflared** for apps with AI API calls that take 30-120s.

```bash
npm install -g cloudflared
cloudflared tunnel --url http://localhost:5001
```

## 3. Gemini API — Quota Handling

Free tier Gemini has per-model daily limits (~20 requests/day for 2.5-flash).
**Always probe models and let the user switch.**

### Model Registry Pattern (REQUIRED for free-tier Gemini):

```python
AVAILABLE_MODELS = [
    "models/gemini-2.5-flash-lite",
    "models/gemini-3.5-flash",
    "models/gemini-3.1-flash-lite",
]

def probe_models(client) -> list[dict]:
    """Test each model for quota. Cache results for 30s."""
    results = []
    for model_id in AVAILABLE_MODELS:
        try:
            client.models.generate_content(model=model_id, contents="ok", ...)
            results.append({"id": model_id, "status": "available"})
        except Exception as e:
            if "429" in str(e):
                results.append({"id": model_id, "status": "quota_exhausted"})
            else:
                results.append({"id": model_id, "status": "error"})
    return results
```

### Frontend: show colored dropdown:
- ✅ Green = available (auto-select first)
- ❌ Red = quota exhausted (disabled)
- ⚠️ Yellow = unknown error

### Model fallback chain (good default):
```
gemini-3.5-flash → gemini-2.5-flash-lite → gemini-3.1-flash-lite
```

## 4. Gemini JSON Parsing — Truncation Recovery

Gemini responses with `max_output_tokens` can truncate JSON mid-string.
**Always apply truncation recovery** — never trust raw `.text` from Gemini.

```python
# 1. Strip markdown fences
text = re.sub(r"^```(?:json)?\s*", "", text)
text = re.sub(r"\s*```$", "", text)

# 2. Extract JSON array (ignore surrounding text)
array_match = re.search(r"\[\s*\{.*", text, re.DOTALL)
if array_match:
    text = array_match.group(0)

# 3. Walk character-by-character tracking string/bracket state
#    to find the last complete JSON object, then close any unclosed brackets
open_objs = open_arrays = 0
in_string = False
cut_pos = len(text)
for i, ch in enumerate(text):
    if ch == '"' and not escape: in_string = not in_string
    if in_string: continue
    if ch == "{": open_objs += 1
    elif ch == "}": open_objs -= 1
    elif ch == "[": open_arrays += 1
    elif ch == "]":
        open_arrays -= 1
        if open_objs == 0 and open_arrays == 0:
            cut_pos = i + 1
            break

text = text[:cut_pos]
text += "]" * (text.count("[") - text.count("]"))
text += "}" * (text.count("{") - text.count("}"))
```

## 5. Gemini File API — Video Upload

For local/uploaded videos, use Gemini's File API:

```python
# Upload
gemini_file = client.files.upload(file=str(local_path))

# Wait for processing (can take 1-2 minutes for large files)
while gemini_file.state.name == "PROCESSING":
    time.sleep(2)
    gemini_file = client.files.get(name=gemini_file.name)

# Use the returned URI in generate_content
part = genai_types.Part.from_uri(
    file_uri=gemini_file.uri,
    mime_type="video/mp4",
)
```

**Important:** Set Flask's `MAX_CONTENT_LENGTH` for large uploads.

## 6. SQLite for Local Persistence

Replace Google Sheets (requires credentials.json + API setup) with SQLite for
zero-config persistence:

```python
import sqlite3

conn = sqlite3.connect("app_history.db")
conn.execute("""
    CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        video_url TEXT NOT NULL,
        overall_score INTEGER NOT NULL,
        technique_ratings TEXT NOT NULL,
        timestamps_notes TEXT NOT NULL,
        verdict TEXT NOT NULL
    )
""")
```

## 7. Error Handling Pattern

Always return JSON even on errors. Wrap AI API calls with specific error messages.

```python
@app.route("/analyze", methods=["POST"])
def analyze():
    try:
        # Gemini
        events = run_gemini_analysis(...)
        # DeepSeek
        coaching = run_deepseek_coaching(...)
        return jsonify({"success": True, ...})
    except ValueError as e:      # 400 — bad input
        return jsonify({"error": str(e)}), 400
    except RuntimeError as e:     # 502 — API failure
        return jsonify({"error": str(e)}), 502
    except Exception as e:        # 500 — unexpected
        return jsonify({"error": f"Internal: {e}"}), 500
```
